package com.dicoding.githubusers.model

data class UserResponse(
    val items: ArrayList<User>
)
